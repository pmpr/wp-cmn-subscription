<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66895804e6910             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Subscription; use Pmpr\Common\Foundation\Container\Container as BaseClass; use Pmpr\Common\Subscription\Interfaces\CommonInterface; abstract class Container extends BaseClass implements CommonInterface { }
