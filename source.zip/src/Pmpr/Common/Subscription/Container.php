<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6633b64cd9ff7             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Subscription; use Pmpr\Common\Foundation\Container\Container as BaseClass; use Pmpr\Common\Subscription\Interfaces\CommonInterface; abstract class Container extends BaseClass implements CommonInterface { }
