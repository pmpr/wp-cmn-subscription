<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6668a92c5c3fb             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Subscription; use Pmpr\Common\Foundation\Container\Container as BaseClass; use Pmpr\Common\Subscription\Interfaces\CommonInterface; abstract class Container extends BaseClass implements CommonInterface { }
