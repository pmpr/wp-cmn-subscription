<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668dab73327b7             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Subscription; use Pmpr\Common\Foundation\Container\Container as BaseClass; use Pmpr\Common\Subscription\Interfaces\CommonInterface; abstract class Container extends BaseClass implements CommonInterface { }
