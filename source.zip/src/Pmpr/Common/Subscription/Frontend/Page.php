<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f6b07a13bc4             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Subscription\Frontend; use Pmpr\Common\Foundation\Frontend\Page as BaseClass; abstract class Page extends BaseClass { }
