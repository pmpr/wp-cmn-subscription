<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6633b64cd9ff7             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Subscription\Frontend; use Pmpr\Common\Foundation\Frontend\Page as BaseClass; use Pmpr\Common\Subscription\Interfaces\CommonInterface; abstract class Page extends BaseClass implements CommonInterface { }
