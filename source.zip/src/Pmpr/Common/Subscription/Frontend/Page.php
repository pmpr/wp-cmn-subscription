<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6688fb3970d67             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Subscription\Frontend; use Pmpr\Common\Foundation\Frontend\Page as BaseClass; use Pmpr\Common\Subscription\Interfaces\CommonInterface; abstract class Page extends BaseClass implements CommonInterface { }
