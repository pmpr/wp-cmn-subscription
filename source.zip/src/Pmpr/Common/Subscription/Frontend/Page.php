<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66cb569f465a3             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Subscription\Frontend; use Pmpr\Common\Foundation\Frontend\Page as BaseClass; use Pmpr\Common\Subscription\Interfaces\CommonInterface; abstract class Page extends BaseClass implements CommonInterface { }
