<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668707b85f736             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Subscription\Frontend; use Pmpr\Common\Foundation\Frontend\Page as BaseClass; use Pmpr\Common\Subscription\Interfaces\CommonInterface; abstract class Page extends BaseClass implements CommonInterface { }
