<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             661cf9faf18b5             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Subscription\Model; use Pmpr\Common\Foundation\ORM\DB\Model; use Pmpr\Common\Subscription\Engine; use Pmpr\Common\Subscription\Interfaces\CommonInterface; abstract class Common extends Model implements CommonInterface { const oayciggqokqmayuy = "\x75\x73\141\147\x65"; const kiwgokskimawckie = self::uswkskaqiieoyacg . self::mswocgcucqoaesaa; const eyoamaoqmumskwam = self::mayesweykoooyugy . self::mswocgcucqoaesaa; const myuqyocawokymysw = self::oayciggqokqmayuy . self::mswocgcucqoaesaa; const qymgycqkoqecugsi = self::eoigaocgcaekssuw . self::mswocgcucqoaesaa; public function ckgmycmaukqgkosk() { parent::ckgmycmaukqgkosk(); $wksoawcgagcgoask = $this->akuociswqmoigkas(); $this->oyeskqayoscwciem()->okgmqaeuaeymaocm($wksoawcgagcgoask)->wiskakymeaywyeuw($wksoawcgagcgoask); } public abstract function uykissogmuaaocsg() : Engine; }
