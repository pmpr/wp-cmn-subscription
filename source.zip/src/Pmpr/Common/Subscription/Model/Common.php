<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f6b07a13bc4             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Subscription\Model; use Pmpr\Common\Foundation\ORM\DB\Model; use Pmpr\Common\Subscription\Engine; abstract class Common extends Model { public function ckgmycmaukqgkosk() { parent::ckgmycmaukqgkosk(); $wksoawcgagcgoask = $this->akuociswqmoigkas(); $this->oyeskqayoscwciem()->okgmqaeuaeymaocm($wksoawcgagcgoask)->wiskakymeaywyeuw($wksoawcgagcgoask); } public abstract function uykissogmuaaocsg() : Engine; }
