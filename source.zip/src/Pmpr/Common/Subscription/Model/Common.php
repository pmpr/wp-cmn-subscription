<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6668a92c5c3fb             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Subscription\Model; use Pmpr\Common\Foundation\ORM\DB\Model; use Pmpr\Common\Subscription\Engine; use Pmpr\Common\Subscription\Interfaces\CommonInterface; abstract class Common extends Model implements CommonInterface { const oayciggqokqmayuy = "\165\163\x61\x67\145"; const kiwgokskimawckie = self::uswkskaqiieoyacg . self::mswocgcucqoaesaa; const eyoamaoqmumskwam = self::mayesweykoooyugy . self::mswocgcucqoaesaa; const myuqyocawokymysw = self::oayciggqokqmayuy . self::mswocgcucqoaesaa; const qymgycqkoqecugsi = self::eoigaocgcaekssuw . self::mswocgcucqoaesaa; public function ckgmycmaukqgkosk() { parent::ckgmycmaukqgkosk(); $wksoawcgagcgoask = $this->akuociswqmoigkas(); $this->oyeskqayoscwciem()->okgmqaeuaeymaocm($wksoawcgagcgoask)->wiskakymeaywyeuw($wksoawcgagcgoask); } public abstract function uykissogmuaaocsg() : Engine; }
