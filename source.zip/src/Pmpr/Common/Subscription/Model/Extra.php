<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f7da1bd6842             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Subscription\Model; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\Interfaces\IconInterface; abstract class Extra extends AbstractSub { public function ckgmycmaukqgkosk() { parent::ckgmycmaukqgkosk(); $this->oyeskqayoscwciem()->myysgyqcumekoueo()->muuwuqssqkaieqge(__("\105\x78\164\162\141\163", PR__CMN__SUBSCRIPTION))->guiaswksukmgageq(__("\x45\x78\164\x72\x61", PR__CMN__SUBSCRIPTION))->yioesawwewqaigow(IconInterface::imoykkmkkkaqgouo)->gemkqqguesukeocw()->wkesqcmiekqoykag()->aseucqksocwomwos()->qemeyueyiwgsokuc(); } public function ewaqwooqoqmcoomi() { $this->cquokmemekqqywgi($this->qoemykoeuecmsmwe(Constants::ciyoccqkiamemcmm)->gswweykyogmsyawy(__("\x56\141\154\165\x65", PR__CMN__SUBSCRIPTION))); parent::ewaqwooqoqmcoomi(); } public function aoqwywcqmoqaukkq() { parent::aoqwywcqmoqaukkq(); $this->mkksewyosgeumwsa($this->ymuegqgyuagyucws(Constants::ciyoccqkiamemcmm)->escqqisecooswqgo()->mkmssscwmeekwgqo()); } }
