<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668682bc6f0ad             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Subscription\Interfaces; use Pmpr\Common\Subscription\Engine; interface EngineInterface { public function uykissogmuaaocsg() : Engine; }
