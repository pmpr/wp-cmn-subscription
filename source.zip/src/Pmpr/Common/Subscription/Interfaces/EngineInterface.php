<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66cb5efd9fc52             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Subscription\Interfaces; use Pmpr\Common\Subscription\Engine; interface EngineInterface { public function uykissogmuaaocsg() : Engine; }
