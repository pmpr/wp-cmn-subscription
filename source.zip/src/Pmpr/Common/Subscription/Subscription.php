<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f7da1bd6842             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Subscription; use Pmpr\Common\Foundation\Container\CommonInitiator; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Subscription\Woocommerce\Woocommerce; class Subscription extends CommonInitiator { public function register() { $this->gkieogwukagigisy(__DIR__, [Constants::qescuiwgsyuikume => static function () { return __("\103\x6f\x6d\155\x6f\x6e\x20\123\x75\142\x73\143\162\151\x70\164\151\157\x6e", PR__CMN__COVER); }, Constants::wuowaiyouwecckaw => false]); } public function mameiwsayuyquoeq() { Woocommerce::symcgieuakksimmu(); } }
