<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66cb5efd9fc52             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Subscription; use Pmpr\Common\Foundation\Container\CommonInitiator; use Pmpr\Common\Subscription\Woocommerce\Woocommerce; class Subscription extends CommonInitiator { public function register() { $this->gkieogwukagigisy(__DIR__, [self::qescuiwgsyuikume => static function () { return __("\103\157\x6d\x6d\157\156\40\123\x75\x62\x73\143\x72\151\160\x74\x69\x6f\x6e", PR__CMN__COVER); }, self::wuowaiyouwecckaw => false]); } public function mameiwsayuyquoeq() { Woocommerce::symcgieuakksimmu(); } }
