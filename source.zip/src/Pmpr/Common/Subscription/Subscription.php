<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6668a92c5c3fb             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Subscription; use Pmpr\Common\Foundation\Container\CommonInitiator; use Pmpr\Common\Subscription\Woocommerce\Woocommerce; class Subscription extends CommonInitiator { public function register() { $this->gkieogwukagigisy(__DIR__, [self::qescuiwgsyuikume => static function () { return __("\x43\x6f\155\x6d\157\156\x20\x53\x75\142\163\143\162\x69\160\x74\x69\x6f\156", PR__CMN__COVER); }, self::wuowaiyouwecckaw => false]); } public function mameiwsayuyquoeq() { Woocommerce::symcgieuakksimmu(); } }
