<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             661e1d64cde85             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Subscription; use Pmpr\Common\Foundation\Container\CommonInitiator; use Pmpr\Common\Subscription\Woocommerce\Woocommerce; class Subscription extends CommonInitiator { public function register() { $this->gkieogwukagigisy(__DIR__, [self::qescuiwgsyuikume => static function () { return __("\x43\x6f\x6d\155\x6f\x6e\40\x53\165\x62\163\x63\162\151\x70\164\x69\157\x6e", PR__CMN__COVER); }, self::wuowaiyouwecckaw => false]); } public function mameiwsayuyquoeq() { Woocommerce::symcgieuakksimmu(); } }
