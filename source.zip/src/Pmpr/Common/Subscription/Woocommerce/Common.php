<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66cb569f465a3             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Subscription\Woocommerce; use Pmpr\Common\Subscription\Container; abstract class Common extends Container { }
