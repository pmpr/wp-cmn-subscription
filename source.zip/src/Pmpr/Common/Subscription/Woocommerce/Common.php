<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6673f42665cf3             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Subscription\Woocommerce; use Pmpr\Common\Subscription\Container; abstract class Common extends Container { }
