<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6668a92c5c3fb             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Subscription\Woocommerce; use Pmpr\Common\Subscription\Container; abstract class Common extends Container { }
