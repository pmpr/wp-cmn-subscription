<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66788371b4ba8             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Subscription\Woocommerce; use Pmpr\Common\Subscription\Container; abstract class Common extends Container { }
